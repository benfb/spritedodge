----- About -----

An incredibly simple attempt at a first game in Ruby.

----- Instructions -----

Move left and right with the arrow keys. Avoid the rocks, collect the gems. Hit P to pause the game, Space to continue after hitting something, R to restart the entire game, and Q to quit.

----- Credits -----

"CuteGod" art by Daniel Cook (Lostgarden.com) 

Music from the artists PeterGMusic, Calamalstr, and 15thDimension on Newgrounds.

Sound effects from the free archive at the Absolute Sound Effects Archive.

Font from Kimberly Geswein on dafont.

All code written by Ben Bailey.